# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
"""Custom Sparse Attention Indexer layers."""

import os
import weakref as _weakref

import torch

import vllm.envs as envs
from vllm._aiter_ops import rocm_aiter_ops
from vllm.forward_context import get_forward_context
from vllm.logger import init_logger
from vllm.model_executor.custom_op import CustomOp
from vllm.platforms import current_platform
from vllm.utils.deep_gemm import (
    fp8_fp4_mqa_logits,
    fp8_fp4_paged_mqa_logits,
    get_paged_mqa_logits_metadata,
    has_deep_gemm,
)
from vllm.utils.platform_utils import num_compute_units
from vllm.utils.torch_utils import (
    LayerNameType,
    _encode_layer_name,
    _resolve_layer_name,
    direct_register_custom_op,
)
from vllm.v1.attention.backends.mla.indexer import (
    DeepseekV32IndexerMetadata,
)
from vllm.v1.attention.ops.common import pack_seq_triton, unpack_seq_triton
from vllm.v1.worker.workspace import current_workspace_manager

if current_platform.is_cuda_alike():
    from vllm import _custom_ops as ops
elif current_platform.is_xpu():
    from vllm._xpu_ops import xpu_ops

logger = init_logger(__name__)

RADIX_TOPK_WORKSPACE_SIZE = 1024 * 1024

# MXFP4 layout: 2 values packed per byte, ue8m0 (1-byte) scale per block of 32.
MXFP4_BLOCK_SIZE = 32


def _env_flag(name: str) -> bool:
    value = os.environ.get(name, "")
    return value.lower() in {"1", "true", "yes", "on"}


def _indexer_profile_accuracy_enabled() -> bool:
    return _env_flag("LMCACHE_INDEXER_PROFILE_ACCURACY") or os.path.exists(
        "/tmp/lmcache_indexer_profile_accuracy"
    )


def _env_int(name: str, default: int) -> int:
    value = os.environ.get(name)
    if value is None:
        return default
    try:
        return int(value)
    except ValueError:
        logger.warning("Invalid integer for %s=%r; using %d", name, value, default)
        return default


def _gather_workspace_shapes(
    total_seq_lens: int,
    head_dim: int,
    fp8_dtype: torch.dtype,
    use_fp4_cache: bool,
) -> tuple[tuple[tuple[int, int], torch.dtype], tuple[tuple[int, int], torch.dtype]]:
    """Return ((values_shape, values_dtype), (scales_shape, scales_dtype)) for
    the K-gather workspace. FP8 path: (T, head_dim) fp8 + (T, 4) uint8 fp32
    scales. MXFP4 path: (T, head_dim // 2) uint8 packed mxfp4 +
    (T, head_dim // MXFP4_BLOCK_SIZE) uint8 ue8m0 scales."""
    if use_fp4_cache:
        return (
            ((total_seq_lens, head_dim // 2), torch.uint8),
            ((total_seq_lens, head_dim // MXFP4_BLOCK_SIZE), torch.uint8),
        )
    return (
        ((total_seq_lens, head_dim), fp8_dtype),
        ((total_seq_lens, 4), torch.uint8),
    )


def kv_cache_as_quant_view(
    kv_cache: torch.Tensor,
    head_dim: int,
    use_fp4_cache: bool,
) -> torch.Tensor:
    """4D ``[num_blocks, block_size, 1, head_width]`` view expected by
    DeepGEMM, from the 3D indexer kv-cache allocation."""
    if use_fp4_cache:
        assert kv_cache.ndim == 3 and kv_cache.dtype == torch.uint8
        num_blocks, block_size, _ = kv_cache.shape
        page_bytes = int(kv_cache.stride(0))
        fp4_bytes = head_dim // 2 + head_dim // MXFP4_BLOCK_SIZE
        return torch.as_strided(
            kv_cache,
            size=(num_blocks, block_size, 1, fp4_bytes),
            stride=(page_bytes, fp4_bytes, fp4_bytes, 1),
        )
    return kv_cache.unsqueeze(-2)


def sparse_attn_indexer(
    hidden_states: torch.Tensor,
    k_cache_prefix: LayerNameType,
    kv_cache: torch.Tensor,
    q_quant: torch.Tensor,
    q_scale: torch.Tensor | None,
    k: torch.Tensor,
    weights: torch.Tensor,
    quant_block_size: int,
    scale_fmt: str | None,
    topk_tokens: int,
    head_dim: int,
    max_model_len: int,
    total_seq_lens: int,
    topk_indices_buffer: torch.Tensor,
    skip_k_cache_insert: bool,
    use_fp4_cache: bool = False,
) -> torch.Tensor:
    # careful! this will be None in dummy run
    attn_metadata = get_forward_context().attn_metadata
    fp8_dtype = current_platform.fp8_dtype()
    k_cache_prefix = _resolve_layer_name(k_cache_prefix)

    # assert isinstance(attn_metadata, dict)
    if not isinstance(attn_metadata, dict):
        # Reserve workspace for indexer during profiling run
        values_spec, scales_spec = _gather_workspace_shapes(
            total_seq_lens, head_dim, fp8_dtype, use_fp4_cache
        )
        current_workspace_manager().get_simultaneous(
            values_spec,
            scales_spec,
            ((RADIX_TOPK_WORKSPACE_SIZE,), torch.uint8),
        )

        # Dummy allocation to simulate for peak logits tensor memory during inference.
        # FP8 elements so elements == bytes
        max_logits_elems = envs.VLLM_SPARSE_INDEXER_MAX_LOGITS_MB * 1024 * 1024
        _ = torch.empty(
            max_logits_elems, dtype=torch.uint8, device=hidden_states.device
        )

        return sparse_attn_indexer_fake(
            hidden_states,
            k_cache_prefix,
            kv_cache,
            q_quant,
            q_scale,
            k,
            weights,
            quant_block_size,
            scale_fmt,
            topk_tokens,
            head_dim,
            max_model_len,
            total_seq_lens,
            topk_indices_buffer,
            skip_k_cache_insert,
            use_fp4_cache,
        )
    attn_metadata_narrowed = attn_metadata[k_cache_prefix]
    assert isinstance(attn_metadata_narrowed, DeepseekV32IndexerMetadata)
    slot_mapping = attn_metadata_narrowed.slot_mapping
    has_decode = attn_metadata_narrowed.num_decodes > 0
    has_prefill = attn_metadata_narrowed.num_prefills > 0
    num_decode_tokens = attn_metadata_narrowed.num_decode_tokens

    # q_scale is required iff the FP4 cache path is enabled; the FP8 path
    # folds the Q scale into `weights` inside fused_indexer_q_rope_quant.
    if use_fp4_cache:
        assert q_scale is not None, "use_fp4_cache=True requires q_scale"
    else:
        assert q_scale is None, "q_scale must be None when use_fp4_cache=False"

    # During speculative decoding, k may be padded to the CUDA graph batch
    # size while slot_mapping only covers actual tokens. Truncate k to avoid
    # out-of-bounds reads in the kernel.
    num_tokens = slot_mapping.shape[0]
    if k is not None:
        k = k[:num_tokens]

    if not skip_k_cache_insert:
        # scale_fmt can be None, but the function expects str
        assert scale_fmt is not None
        assert not use_fp4_cache, "Unfused FP4 Insert is not supported yet"
        ops.indexer_k_quant_and_cache(
            k,
            kv_cache,
            slot_mapping,
            quant_block_size,
            scale_fmt,
        )

    topk_indices_buffer[: hidden_states.shape[0]] = -1
    if has_prefill:
        prefill_metadata = attn_metadata_narrowed.prefill
        assert prefill_metadata is not None

        # Get the full shared workspace buffers once (will allocate on first use).
        # Layout switches between FP8 (head_dim bytes + 4-byte fp32 scale) and
        # MXFP4 (head_dim/2 bytes packed + head_dim/MXFP4_BLOCK_SIZE ue8m0
        # scales) based on use_fp4_cache.
        workspace_manager = current_workspace_manager()
        values_spec, scales_spec = _gather_workspace_shapes(
            total_seq_lens, head_dim, fp8_dtype, use_fp4_cache
        )
        k_quant_full, k_scale_full = workspace_manager.get_simultaneous(
            values_spec,
            scales_spec,
        )
        for chunk in prefill_metadata.chunks:
            k_quant = k_quant_full[: chunk.total_seq_lens]
            k_scale = k_scale_full[: chunk.total_seq_lens]

            if not chunk.skip_kv_gather:
                ops.cp_gather_indexer_k_quant_cache(
                    kv_cache,
                    k_quant,
                    k_scale,
                    chunk.block_table,
                    chunk.cu_seq_lens,
                )

            q_slice = q_quant[chunk.token_start : chunk.token_end]
            q_scale_slice = (
                q_scale[chunk.token_start : chunk.token_end]
                if q_scale is not None
                else None
            )
            # DeepGEMM scalar-type tags (zero-copy): MXFP4 values → int8
            # (kPackedFP4), scales → int32 squeezed to 1-D kv_sf / 2-D q_sf.
            if use_fp4_cache:
                q_slice_cast = q_slice.view(torch.int8)
                k_quant_cast = k_quant.view(torch.int8)
                k_scale_cast = k_scale.view(torch.int32).squeeze(-1)
            else:
                q_slice_cast = q_slice
                k_quant_cast = k_quant
                k_scale_cast = k_scale.view(torch.float32).squeeze(-1)
            logits = fp8_fp4_mqa_logits(
                (q_slice_cast, q_scale_slice),
                (k_quant_cast, k_scale_cast),
                weights[chunk.token_start : chunk.token_end],
                chunk.cu_seqlen_ks,
                chunk.cu_seqlen_ke,
                clean_logits=False,
            )
            num_rows = logits.shape[0]

            topk_indices = topk_indices_buffer[
                chunk.token_start : chunk.token_end, :topk_tokens
            ]

            if current_platform.is_xpu():
                xpu_ops.top_k_per_row_prefill(  # type: ignore[attr-defined]
                    logits,
                    chunk.cu_seqlen_ks,
                    chunk.cu_seqlen_ke,
                    topk_indices,
                    num_rows,
                    logits.stride(0),
                    logits.stride(1),
                    topk_tokens,
                )
            else:
                torch.ops._C.top_k_per_row_prefill(
                    logits,
                    chunk.cu_seqlen_ks,
                    chunk.cu_seqlen_ke,
                    topk_indices,
                    num_rows,
                    logits.stride(0),
                    logits.stride(1),
                    topk_tokens,
                )

    if has_decode:
        decode_metadata = attn_metadata_narrowed.decode
        assert decode_metadata is not None
        kv_cache = kv_cache_as_quant_view(kv_cache, head_dim, use_fp4_cache)
        decode_lens = decode_metadata.decode_lens
        if decode_metadata.requires_padding:
            # pad in edge case where we have short chunked prefill length <
            # decode_threshold since we unstrictly split
            # prefill and decode by decode_threshold
            # (currently set to 1 + speculative tokens).
            # FP8 Q is float8_e4m3fn (pack_seq_triton's fp32 pad path is OK —
            # downstream context_lens masks stale slots). MXFP4 Q is two
            # uint8 tensors (values + ue8m0 scales) — use the dedicated uint8
            # packer with pad_byte=0 so padded slots dequantize to 0 and
            # can't produce NaN/Inf in the logits kernel.
            if q_scale is not None:
                padded_q_quant_decode_tokens = pack_seq_triton(
                    q_quant[:num_decode_tokens], decode_lens, pad_value=0
                )
                padded_q_scale = pack_seq_triton(
                    q_scale[:num_decode_tokens], decode_lens, pad_value=0
                )
            else:
                padded_q_quant_decode_tokens = pack_seq_triton(
                    q_quant[:num_decode_tokens], decode_lens
                )
                padded_q_scale = None
        else:
            padded_q_quant_decode_tokens = q_quant[:num_decode_tokens].reshape(
                decode_lens.shape[0], -1, *q_quant.shape[1:]
            )
            if q_scale is not None:
                padded_q_scale = q_scale[:num_decode_tokens].reshape(
                    decode_lens.shape[0], -1, *q_scale.shape[1:]
                )
            else:
                padded_q_scale = None
        # TODO: move and optimize below logic with triton kernels
        batch_size = padded_q_quant_decode_tokens.shape[0]
        next_n = padded_q_quant_decode_tokens.shape[1]
        num_padded_tokens = batch_size * next_n
        seq_lens = decode_metadata.seq_lens[:batch_size]
        # seq_lens is always 2D: (B, next_n) for native spec decode, (B, 1)
        # otherwise. deep_gemm fp8_fp4_paged_mqa_logits requires 2D context_lens;
        # the downstream topk kernels accept both 1D and 2D.
        padded_q_quant_cast = (
            padded_q_quant_decode_tokens.view(torch.int8)
            if use_fp4_cache
            else padded_q_quant_decode_tokens
        )
        logits = fp8_fp4_paged_mqa_logits(
            (padded_q_quant_cast, padded_q_scale),
            kv_cache,
            weights[:num_padded_tokens],
            seq_lens,
            decode_metadata.block_table,
            decode_metadata.schedule_metadata,
            max_model_len=max_model_len,
            clean_logits=False,
        )
        num_rows = logits.shape[0]
        topk_indices = topk_indices_buffer[:num_padded_tokens, :topk_tokens]

        if current_platform.is_cuda() and topk_tokens in (512, 1024, 2048):
            workspace_manager = current_workspace_manager()
            (topk_workspace,) = workspace_manager.get_simultaneous(
                ((RADIX_TOPK_WORKSPACE_SIZE,), torch.uint8),
            )
            torch.ops._C.persistent_topk(
                logits,
                seq_lens,
                topk_indices,
                topk_workspace,
                topk_tokens,
                attn_metadata_narrowed.max_seq_len,
            )
        else:
            if current_platform.is_xpu():
                xpu_ops.top_k_per_row_decode(  # type: ignore[attr-defined]
                    logits,
                    next_n,
                    seq_lens,
                    topk_indices,
                    num_rows,
                    logits.stride(0),
                    logits.stride(1),
                    topk_tokens,
                )
            else:
                torch.ops._C.top_k_per_row_decode(
                    logits,
                    next_n,
                    seq_lens,
                    topk_indices,
                    num_rows,
                    logits.stride(0),
                    logits.stride(1),
                    topk_tokens,
                )

        if decode_metadata.requires_padding:
            # if padded, we need to unpack
            # the topk indices removing padded tokens
            topk_indices = unpack_seq_triton(
                topk_indices.reshape(batch_size, -1, topk_indices.shape[-1]),
                decode_lens,
            )
            topk_indices_buffer[: topk_indices.shape[0], : topk_indices.shape[-1]] = (
                topk_indices
            )

    return topk_indices_buffer


def sparse_attn_indexer_fake(
    hidden_states: torch.Tensor,
    k_cache_prefix: LayerNameType,
    kv_cache: torch.Tensor,
    q_quant: torch.Tensor,
    q_scale: torch.Tensor | None,
    k: torch.Tensor,
    weights: torch.Tensor,
    quant_block_size: int,
    scale_fmt: str | None,
    topk_tokens: int,
    head_dim: int,
    max_model_len: int,
    total_seq_lens: int,
    topk_indices_buffer: torch.Tensor | None,
    skip_k_cache_insert: bool,
    use_fp4_cache: bool = False,
) -> torch.Tensor:
    return topk_indices_buffer


direct_register_custom_op(
    op_name="sparse_attn_indexer",
    op_func=sparse_attn_indexer,
    mutates_args=["topk_indices_buffer"],
    fake_impl=sparse_attn_indexer_fake,
    dispatch_key=current_platform.dispatch_key,
)


@CustomOp.register("sparse_attn_indexer")
class SparseAttnIndexer(CustomOp):
    """Sparse Attention Indexer Custom Op Layer. This layer is extracted as a
    separate custom op since it involves heavy custom kernels like `mqa_logits`,
    `paged_mqa_logits` and `top_k_per_row`, etc. Those kernels maybe requires
    specific memory layout or implementation for different hardware backends to
    achieve optimal performance.

    For now, the default native path will use CUDA backend path. Other platform
    may requires add the corresponding Custom Op name `sparse_attn_indexer` to
    `custom_ops` in `CompilationConfig` to enable the platform specific path.
    """

    def __init__(
        self,
        k_cache,
        quant_block_size: int,
        scale_fmt: str,
        topk_tokens: int,
        head_dim: int,
        max_model_len: int,
        max_total_seq_len: int,
        topk_indices_buffer: torch.Tensor,
        skip_k_cache_insert: bool = False,
        use_fp4_cache: bool = False,
    ):
        super().__init__()
        self.k_cache = k_cache
        self.quant_block_size = quant_block_size
        self.scale_fmt = scale_fmt
        self.topk_tokens = topk_tokens
        self.head_dim = head_dim
        self.max_model_len = max_model_len
        self.max_total_seq_len = max_total_seq_len
        self.topk_indices_buffer = topk_indices_buffer
        self.skip_k_cache_insert = skip_k_cache_insert
        self.use_fp4_cache = use_fp4_cache
        # Set by IndexerSSDManager.attach() when SSD offloading is active.
        self.ssd_manager = None
        # Decoded CSA layer_id (set by Indexer.__init__ via attach_ssd_manager).
        self.csa_layer_id: int = -1
        self._profile_accuracy_limit = _env_int(
            "LMCACHE_INDEXER_PROFILE_ACCURACY_LIMIT", 64
        )
        self._profile_accuracy_seen = 0
        _SPARSE_ATTN_REGISTRY.add(self)
        if current_platform.is_cuda() and not has_deep_gemm():
            raise RuntimeError(
                "Sparse Attention Indexer CUDA op requires DeepGEMM to be installed."
            )

    def forward_native(
        self,
        hidden_states: torch.Tensor,
        q_quant: torch.Tensor | tuple[torch.Tensor, torch.Tensor],
        k: torch.Tensor,
        weights: torch.Tensor,
    ):
        if current_platform.is_cuda() or current_platform.is_xpu():
            return self.forward_cuda(hidden_states, q_quant, k, weights)
        elif current_platform.is_rocm():
            return self.forward_hip(hidden_states, q_quant, k, weights)
        else:
            raise NotImplementedError(
                "SparseAttnIndexer native forward is only implemented for "
                "CUDA, ROCm and XPU platforms."
            )

    def forward_cuda(
        self,
        hidden_states: torch.Tensor,
        q_quant: torch.Tensor | tuple[torch.Tensor, torch.Tensor],
        k: torch.Tensor,
        weights: torch.Tensor,
    ):
        # FP8 path: single tensor (per-token scale is folded into `weights`).
        # FP4 path: (values, scales) tuple with scales required by the kernel.
        if isinstance(q_quant, tuple):
            q_values, q_scale = q_quant
        else:
            q_values, q_scale = q_quant, None

        # SSD pool path: only for decode-only steps.  Prefill must run the normal
        # path so the IndexerCache is populated; we trigger async SSD eviction
        # at the end of a pure-prefill step.
        _ctx_meta = None
        _in_prefill = False
        _in_decode = False
        if self.ssd_manager is not None and self.csa_layer_id >= 0:
            _attn_meta = get_forward_context().attn_metadata
            if isinstance(_attn_meta, dict):
                _ctx_meta = _attn_meta.get(
                    _resolve_layer_name(_encode_layer_name(self.k_cache.prefix))
                )
            if _ctx_meta is not None:
                _in_prefill = getattr(_ctx_meta, "num_prefills", 0) > 0
                _in_decode = getattr(_ctx_meta, "num_decodes", 0) > 0
            if _in_decode and not _in_prefill:
                return self._forward_cuda_pool(hidden_states, q_values, q_scale, k, weights)

        result = torch.ops.vllm.sparse_attn_indexer(
            hidden_states,
            _encode_layer_name(self.k_cache.prefix),
            self.k_cache.kv_cache,
            q_values,
            q_scale,
            k,
            weights,
            self.quant_block_size,
            self.scale_fmt,
            self.topk_tokens,
            self.head_dim,
            self.max_model_len,
            self.max_total_seq_len,
            self.topk_indices_buffer,
            self.skip_k_cache_insert,
            self.use_fp4_cache,
        )

        # After a pure-prefill step with SSD manager active: submit async eviction.
        if (self.ssd_manager is not None and self.csa_layer_id >= 0
                and _in_prefill and not _in_decode and _ctx_meta is not None):
            self._trigger_evict_after_prefill(_ctx_meta)

        return result

    def _forward_cuda_pool(
        self,
        hidden_states: torch.Tensor,
        q_values: torch.Tensor,
        q_scale: torch.Tensor | None,
        k: torch.Tensor,
        weights: torch.Tensor,
    ) -> torch.Tensor:
        """Pool-based scoring path used when IndexerSSDManager is active.

        1. Drain any pending async NVMe reads into the HBM pool.
        2. Insert the current step's new K vectors (k) into the pool.
        3. Score q against the pool using fp8_fp4_paged_mqa_logits.
        4. Translate pool-slot topk → global token IDs; record for next step.
        """
        mgr = self.ssd_manager
        layer_id = self.csa_layer_id

        if hidden_states.shape[0] != 1:
            raise NotImplementedError(
                "IndexerSSDManager pool path currently supports single-token "
                "decode only."
            )

        _ctx_meta = None
        _attn_meta = get_forward_context().attn_metadata
        if isinstance(_attn_meta, dict):
            _ctx_meta = _attn_meta.get(
                _resolve_layer_name(_encode_layer_name(self.k_cache.prefix))
            )

        decode_token_raw = None
        if (
            _ctx_meta is not None
            and k is not None
            and k.shape[0] > 0
            and not self.skip_k_cache_insert
        ):
            slot_mapping = _ctx_meta.slot_mapping
            if slot_mapping.shape[0] > 0:
                slot = int(slot_mapping[0].item())
                if slot >= 0:
                    block_size = self.k_cache.kv_cache.shape[1]
                    block_idx = slot // block_size
                    block_offset = slot % block_size
                    assert self.scale_fmt is not None
                    assert not self.use_fp4_cache, (
                        "Unfused FP4 Insert is not supported yet"
                    )
                    ops.indexer_k_quant_and_cache(
                        k[:1],
                        self.k_cache.kv_cache,
                        slot_mapping[:1],
                        self.quant_block_size,
                        self.scale_fmt,
                    )
                    decode_token_raw = (
                        self.k_cache.kv_cache[block_idx, block_offset]
                        .detach()
                        .reshape(-1)
                        .cpu()
                        .numpy()
                        .tobytes()
                    )

        # Step 1: drain pending async reads
        pool_tensor, pool_block_table = mgr.prepare_pool(layer_id)
        if decode_token_raw is not None:
            mgr.insert_decode_token(layer_id, decode_token_raw)

        # Step 3: score against pool. The pool is exposed as DeepGEMM-compatible
        # 64-token pages; flattened logits still map 1:1 to pool slots.
        pool_block_size = pool_tensor.shape[1]
        pool_size = pool_tensor.shape[0] * pool_block_size
        # fp8_fp4_paged_mqa_logits expects q as [B, next_n, n_heads, head_dim]; add B dim.
        q_values_4d = q_values.unsqueeze(0)
        q_scale_4d = q_scale.unsqueeze(0) if q_scale is not None else None
        seq_lens = torch.tensor(
            [[pool_size]], dtype=torch.int32, device=pool_tensor.device
        )
        device_index = pool_tensor.device.index
        if device_index is None:
            device_index = torch.cuda.current_device()
        schedule_metadata = get_paged_mqa_logits_metadata(
            seq_lens, pool_block_size, num_compute_units(device_index)
        )
        result = fp8_fp4_paged_mqa_logits(
            (q_values_4d, q_scale_4d) if q_scale is not None else (q_values_4d, None),
            pool_tensor,
            weights[:1],
            seq_lens,
            pool_block_table,
            schedule_metadata,
            max_model_len=pool_size,
            clean_logits=False,
        )

        # Topk from pool logits
        pool_ids = mgr.pool_ids_for_layer(layer_id)
        valid_pool_size = int((pool_ids >= 0).sum().item())
        topk_k = min(self.topk_tokens, valid_pool_size)
        if topk_k <= 0:
            self.topk_indices_buffer[:1, : self.topk_tokens] = -1
            return self.topk_indices_buffer

        result = result.clone()
        invalid_slots = pool_ids < 0
        if invalid_slots.any():
            result.view(-1)[invalid_slots] = torch.finfo(result.dtype).min
        topk_pool_slots = torch.topk(result.view(-1), topk_k, largest=True).indices.int()
        topk_global = mgr.translate_pool_slots(layer_id, topk_pool_slots).to(
            dtype=self.topk_indices_buffer.dtype
        )
        self.topk_indices_buffer[:1, : self.topk_tokens] = -1
        self.topk_indices_buffer[0, :topk_global.shape[0]] = topk_global

        # Step 4: record true topk for next step's speculative prefetch
        mgr.record_global_topk(layer_id, topk_global)
        if _indexer_profile_accuracy_enabled():
            self._profile_pool_accuracy(
                layer_id,
                pool_ids,
                topk_global,
                result,
                q_values_4d,
                q_scale_4d,
                weights,
                _ctx_meta,
            )

        return self.topk_indices_buffer

    def _profile_pool_accuracy(
        self,
        layer_id: int,
        pool_ids: torch.Tensor,
        pool_topk_global: torch.Tensor,
        pool_logits: torch.Tensor,
        q_values_4d: torch.Tensor,
        q_scale_4d: torch.Tensor | None,
        weights: torch.Tensor,
        ctx_meta: "DeepseekV32IndexerMetadata | None",
    ) -> None:
        """Compare SSD-pool top-k with the normal full-cache top-k path."""
        if ctx_meta is None or self._profile_accuracy_seen >= self._profile_accuracy_limit:
            return
        decode_metadata = ctx_meta.decode
        if decode_metadata is None:
            return

        kv_cache = kv_cache_as_quant_view(
            self.k_cache.kv_cache,
            self.head_dim,
            self.use_fp4_cache,
        )
        seq_lens = decode_metadata.seq_lens[:1]
        full_logits = fp8_fp4_paged_mqa_logits(
            (q_values_4d, q_scale_4d) if q_scale_4d is not None else (q_values_4d, None),
            kv_cache,
            weights[:1],
            seq_lens,
            decode_metadata.block_table[:1],
            decode_metadata.schedule_metadata,
            max_model_len=self.max_model_len,
            clean_logits=False,
        )
        if int(seq_lens.reshape(-1)[0].item()) <= 0:
            return
        full_topk_buffer = torch.empty(
            (full_logits.shape[0], self.topk_tokens),
            dtype=self.topk_indices_buffer.dtype,
            device=full_logits.device,
        )
        num_rows = full_logits.shape[0]
        next_n = 1
        if current_platform.is_cuda() and self.topk_tokens in (512, 1024, 2048):
            workspace_manager = current_workspace_manager()
            (topk_workspace,) = workspace_manager.get_simultaneous(
                ((RADIX_TOPK_WORKSPACE_SIZE,), torch.uint8),
            )
            torch.ops._C.persistent_topk(
                full_logits,
                seq_lens,
                full_topk_buffer,
                topk_workspace,
                self.topk_tokens,
                ctx_meta.max_seq_len,
            )
        else:
            if current_platform.is_xpu():
                xpu_ops.top_k_per_row_decode(  # type: ignore[attr-defined]
                    full_logits,
                    next_n,
                    seq_lens,
                    full_topk_buffer,
                    num_rows,
                    full_logits.stride(0),
                    full_logits.stride(1),
                    self.topk_tokens,
                )
            else:
                torch.ops._C.top_k_per_row_decode(
                    full_logits,
                    next_n,
                    seq_lens,
                    full_topk_buffer,
                    num_rows,
                    full_logits.stride(0),
                    full_logits.stride(1),
                    self.topk_tokens,
                )
        full_topk = full_topk_buffer.reshape(-1)
        full_topk = full_topk[full_topk >= 0]
        if full_topk.numel() == 0:
            return
        pool_valid = pool_topk_global[pool_topk_global >= 0].to(torch.long)
        if pool_valid.numel() == 0:
            return

        compare_k = min(full_topk.numel(), pool_valid.numel())
        pool_compare = pool_valid[:compare_k]
        full_compare = full_topk[:compare_k]
        matches = torch.isin(full_compare, pool_compare).sum().item()

        resident_pool_ids = pool_ids[pool_ids >= 0].to(
            device=full_topk.device, dtype=full_topk.dtype
        )
        resident_hits = torch.isin(full_compare, resident_pool_ids).sum().item()
        shared = full_compare[torch.isin(full_compare, resident_pool_ids)]
        logit_max_abs_diff = 0.0
        if shared.numel() > 0:
            sample = shared[: min(shared.numel(), 64)].to(dtype=resident_pool_ids.dtype)
            full_scores = full_logits.reshape(-1)[sample.to(device=full_logits.device)]
            pool_slots = []
            pool_ids_cpu = pool_ids.detach().cpu()
            slot_lookup = {
                int(tid): idx for idx, tid in enumerate(pool_ids_cpu.tolist()) if tid >= 0
            }
            for tid in sample.detach().cpu().tolist():
                pool_slots.append(slot_lookup[int(tid)])
            pool_slots_tensor = torch.tensor(
                pool_slots, dtype=torch.long, device=pool_logits.device
            )
            pool_scores = pool_logits.reshape(-1)[pool_slots_tensor]
            logit_max_abs_diff = float(
                (full_scores.float() - pool_scores.float()).abs().max().item()
            )
        recall = float(matches) / float(compare_k)
        coverage = float(resident_hits) / float(compare_k)
        self._profile_accuracy_seen += 1
        logger.info(
            "IndexerSSDManager: profile_accuracy layer %d sample=%d k=%d "
            "pool_vs_full_recall=%.4f full_topk_pool_coverage=%.4f "
            "shared_logit_max_abs_diff=%.6f",
            layer_id,
            self._profile_accuracy_seen,
            compare_k,
            recall,
            coverage,
            logit_max_abs_diff,
        )

    def _trigger_evict_after_prefill(self, meta: "DeepseekV32IndexerMetadata") -> None:
        """Submit async SSD eviction after initial prefill.

        Extracts the slot_mapping from prefill metadata and the prefill topk from
        topk_indices_buffer, then hands them to the manager's thread pool so
        the next decode step finds a populated pool.

        Args:
            meta: DeepseekV32IndexerMetadata for this CSA layer's prefill step.
        """
        mgr = self.ssd_manager
        layer_id = self.csa_layer_id

        prefill = meta.prefill
        if prefill is None or not prefill.chunks:
            logger.warning(
                "IndexerSSDManager: skip prefill eviction for layer %d because "
                "metadata has no prefill chunks",
                layer_id,
            )
            return
        if any(chunk.num_reqs != 1 for chunk in prefill.chunks):
            raise NotImplementedError(
                "IndexerSSDManager prefill eviction currently supports a single "
                "prefill request."
            )

        seq_len = max(int(chunk.total_seq_lens) for chunk in prefill.chunks)
        block_table = prefill.chunks[-1].block_table

        # topk_indices_buffer is [num_query_tokens, topk_tokens] during prefill.
        # The last prefill query row is the relevant seed for the first decode step.
        topk_buf = self.topk_indices_buffer
        if topk_buf.ndim >= 2:
            topk_row = topk_buf[max(meta.num_prefill_tokens - 1, 0)]
        else:
            topk_row = topk_buf
        valid = topk_row[topk_row >= 0]
        seed_token_ids = [
            int(x) for x in valid.cpu().tolist() if int(x) < seq_len
        ]

        # Copy CUDA tensors to CPU on this thread before submitting to thread pool.
        kv_cache_cpu = self.k_cache.kv_cache.cpu()
        block_table_cpu = block_table.cpu()

        mgr.submit_evict_after_prefill(
            layer_id,
            kv_cache_cpu,
            seq_len,
            seed_token_ids,
            block_table_cpu=block_table_cpu,
        )

    def forward_hip(
        self,
        hidden_states: torch.Tensor,
        q_quant: torch.Tensor | tuple[torch.Tensor, torch.Tensor],
        k: torch.Tensor,
        weights: torch.Tensor,
    ):
        assert not self.use_fp4_cache, "AMD platform doesn't support fp4 cache yet"
        assert isinstance(q_quant, torch.Tensor), (
            "AMD sparse_attn_indexer expects a single FP8 q_quant tensor"
        )
        if self.skip_k_cache_insert or not rocm_aiter_ops.is_enabled():
            from vllm.v1.attention.ops.rocm_aiter_mla_sparse import (
                rocm_aiter_sparse_attn_indexer_native,
            )

            return rocm_aiter_sparse_attn_indexer_native(
                hidden_states,
                _encode_layer_name(self.k_cache.prefix),
                self.k_cache.kv_cache,
                q_quant,
                k,
                weights,
                self.quant_block_size,
                self.scale_fmt,
                self.topk_tokens,
                self.head_dim,
                self.max_model_len,
                self.max_total_seq_len,
                self.topk_indices_buffer,
                skip_k_cache_insert=self.skip_k_cache_insert,
            )
        if rocm_aiter_ops.is_enabled():
            return torch.ops.vllm.rocm_aiter_sparse_attn_indexer(
                hidden_states,
                _encode_layer_name(self.k_cache.prefix),
                self.k_cache.kv_cache,
                q_quant,
                k,
                weights,
                self.quant_block_size,
                self.scale_fmt,
                self.topk_tokens,
                self.head_dim,
                self.max_model_len,
                self.max_total_seq_len,
                self.topk_indices_buffer,
            )
        raise RuntimeError("Sparse attention indexer ROCm path could not be selected.")


# Module-level WeakSet registry — populated by SparseAttnIndexer.__init__.
# Used by vllm_v1_adapter to find CSA indexer layers without gc.get_objects().
_SPARSE_ATTN_REGISTRY: _weakref.WeakSet["SparseAttnIndexer"] = (
    _weakref.WeakSet()
)
