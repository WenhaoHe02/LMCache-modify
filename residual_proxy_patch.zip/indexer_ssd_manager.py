# SPDX-License-Identifier: Apache-2.0
"""
IndexerSSDManager — SSD-backed HBM pool for DeepSeek V4 CSA Indexer cache.

Architecture
------------
vLLM's SparseAttnIndexer normally scores each decode step against the full
paged IndexerCache (all context tokens).  For very long contexts the full
KV tensor doesn't fit in HBM.  This module replaces the full-context scoring
with a pool-based approach:

  * Per CSA layer: a fixed-size HBM pool [pool_size, 1, 1, head_dim_with_scale]
    in the same FP8-quantized layout that fp8_fp4_paged_mqa_logits expects
    (block_size = 1 so pool slot == token index).
  * All other token K-vectors are stored on SSD (one flat file per CSA layer).
  * Two-tier LRU:
      _lru_resident — the prefill seed blocks (top-1024 from initial prefill),
                      evicted last.
      _lru_ordinary — speculatively prefetched / new decode blocks, evicted
                      first.
  * Speculative prefetch: the caller (DeepseekV2DecoderLayer) fires
    fire_async_for_layer() before MoE FFN.  The FFN window (~3 ms) overlaps
    with NVMe reads so blocks are ready when drain_into_pool() is called at
    the start of the next CSA layer's scoring.

Integration with vLLM
---------------------
  1. IndexerSSDManager is created by LMCache's vllm_v1_adapter when it detects
     CSA (DeepseekV32IndexerCache) layers.
  2. DeepseekV2DecoderLayer.forward() calls:
       mgr.fire_async_for_layer(next_csa_layer_id, prev_topk)   # before FFN
  3. SparseAttnIndexer.forward_cuda() calls:
       kv, block_table, topk_translate = mgr.prepare_pool(layer_id, seq_id)
       # run fp8_fp4_paged_mqa_logits with kv / block_table
       # translate pool-slot topk → global token IDs
       mgr.record_topk(layer_id, seq_id, global_topk_ids)

Only single-sequence decode is supported in this version (batch_size = 1).
Multi-sequence support can be added by keying pool state per seq_id.
"""
from __future__ import annotations

import os
import threading
from collections import OrderedDict
from concurrent.futures import Future, ThreadPoolExecutor
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

import torch

from lmcache.logging import init_logger

logger = init_logger(__name__)
DEEPGEMM_PAGED_BLOCK_SIZE = 64

# ---------------------------------------------------------------------------
# Environment flag: set LMCACHE_DISABLE_RESIDENT_INDEXER=1 to use flat LRU
# ---------------------------------------------------------------------------
_RESIDENT_ENABLED: bool = os.environ.get("LMCACHE_DISABLE_RESIDENT_INDEXER", "0") != "1"
_RESIDUAL_PROXY_ENABLED: bool = (
    os.environ.get("LMCACHE_INDEXER_ENABLE_RESIDUAL_PROXY", "").lower()
    in {"1", "true", "yes", "on"}
)


# ---------------------------------------------------------------------------
# Low-level pread helper (Linux/macOS)
# ---------------------------------------------------------------------------

def _pread(fd: int, size: int, offset: int) -> bytes:
    """Read *size* bytes from *fd* at *offset* without moving the file cursor."""
    buf = bytearray(size)
    view = memoryview(buf)
    pos = 0
    while pos < size:
        chunk = os.pread(fd, size - pos, offset + pos)
        if not chunk:
            break
        n = len(chunk)
        view[pos : pos + n] = chunk
        pos += n
    return bytes(buf[:pos])


def _pwrite(fd: int, data: bytes, offset: int) -> None:
    """Write *data* to *fd* at *offset* without moving the file cursor."""
    view = memoryview(data)
    pos = 0
    while pos < len(data):
        n = os.pwrite(fd, view[pos:], offset + pos)
        pos += n


# ---------------------------------------------------------------------------
# SSD block store — flat file, one entry per token
# ---------------------------------------------------------------------------

class IndexerBlockStore:
    """Per-CSA-layer flat SSD file storing FP8-quantized K vectors.

    Layout: token_id * token_bytes  →  raw bytes (uint8, head_dim_with_scale
    bytes per token).  The file is pre-sized lazily (sparse file on Linux).
    """

    def __init__(
        self,
        store_dir: str,
        layer_id: int,
        token_bytes: int,
        max_seq_len: int,
    ) -> None:
        """
        Args:
            store_dir: Directory for SSD files.
            layer_id: CSA layer index (used in filename).
            token_bytes: Bytes per token (head_dim_with_scale).
            max_seq_len: Maximum context length (determines file capacity).
        """
        Path(store_dir).mkdir(parents=True, exist_ok=True)
        self._path = Path(store_dir) / f"indexer_layer_{layer_id:03d}.bin"
        self._token_bytes = token_bytes
        self._fd: Optional[int] = None
        # Pre-create sparse file
        if not self._path.exists():
            with open(self._path, "wb") as f:
                f.seek(max_seq_len * token_bytes - 1)
                f.write(b"\x00")

    def _open(self) -> int:
        if self._fd is None:
            self._fd = os.open(str(self._path), os.O_RDWR | os.O_CREAT)
        return self._fd

    def read_token(self, token_id: int) -> bytes:
        """Synchronously read one token's K vector from SSD."""
        fd = self._open()
        return _pread(fd, self._token_bytes, token_id * self._token_bytes)

    def write_token(self, token_id: int, data: bytes) -> None:
        """Write one token's K vector to SSD."""
        if len(data) != self._token_bytes:
            raise ValueError(
                f"Expected {self._token_bytes} bytes, got {len(data)}"
            )
        fd = self._open()
        _pwrite(fd, data, token_id * self._token_bytes)

    def read_tokens_batch(self, token_ids: List[int]) -> List[bytes]:
        """Read multiple token K vectors from SSD (sequential pread calls)."""
        return [self.read_token(tid) for tid in token_ids]

    def close(self) -> None:
        if self._fd is not None:
            os.close(self._fd)
            self._fd = None


# ---------------------------------------------------------------------------
# Per-layer HBM pool
# ---------------------------------------------------------------------------

class IndexerHBMPool:
    """Fixed-size HBM tensor holding FP8-quantized K vectors for one CSA layer.

    Pool layout matches vLLM's IndexerCache: [pool_size, 1, 1, token_bytes]
    with block_size = 1, so that fp8_fp4_paged_mqa_logits can score against
    the pool by passing a sequential block_table [0..pool_size-1].

    LRU eviction uses two tiers when _RESIDENT_ENABLED:
      _lru_resident: prefill-seed slots (lowest eviction priority)
      _lru_ordinary: all other slots
    """

    def __init__(
        self,
        pool_size: int,
        token_bytes: int,
        device: torch.device,
    ) -> None:
        """
        Args:
            pool_size: Maximum number of tokens held in HBM.
            token_bytes: Bytes per token (head_dim_with_scale).
            device: CUDA device.
        """
        block_size = DEEPGEMM_PAGED_BLOCK_SIZE
        num_blocks = (pool_size + block_size - 1) // block_size
        self._pool_size = num_blocks * block_size
        self._token_bytes = token_bytes
        self.block_size = block_size

        # [pool_size, 1, 1, token_bytes] uint8 — same layout as vLLM IndexerCache
        self.pool_tensor: torch.Tensor = torch.zeros(
            num_blocks, block_size, 1, token_bytes,
            dtype=torch.uint8,
            device=device,
        )
        # pool slot → global token ID (-1 = empty)
        self.pool_ids: torch.Tensor = torch.full(
            (self._pool_size,), -1, dtype=torch.int64, device=device,
        )
        # block_table for fp8_fp4_paged_mqa_logits: [1, pool_size] int32
        self.block_table: torch.Tensor = torch.arange(
            num_blocks, dtype=torch.int32, device=device,
        ).unsqueeze(0)

        # CPU-side index structures
        self._id_to_slot: Dict[int, int] = {}
        self._free: List[int] = list(range(self._pool_size))
        self._lru_ordinary: OrderedDict[int, None] = OrderedDict()
        self._lru_resident: OrderedDict[int, None] = OrderedDict()
        self._resident_slots: Set[int] = set()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def contains(self, token_id: int) -> bool:
        """Return True if *token_id* is currently in the HBM pool."""
        return token_id in self._id_to_slot

    def insert(self, token_id: int, data: bytes) -> int:
        """Insert *token_id* with raw *data* bytes; return its pool slot.

        If *token_id* is already present, promote it in LRU and return its
        existing slot without writing data.

        Args:
            token_id: Global token position index.
            data: Raw uint8 bytes of length token_bytes.

        Returns:
            Pool slot index.
        """
        if token_id in self._id_to_slot:
            slot = self._id_to_slot[token_id]
            self._touch(slot)
            return slot

        slot = self._free.pop() if self._free else self._evict_one()
        self.pool_tensor.view(-1, self._token_bytes)[slot] = torch.frombuffer(
            bytearray(data), dtype=torch.uint8
        )
        self.pool_ids[slot] = token_id
        self._id_to_slot[token_id] = slot
        self._lru_ordinary[slot] = None
        return slot

    def protect(self, token_id: int) -> None:
        """Mark *token_id* as a resident (prefill-seed) block.

        Resident blocks are moved to the resident LRU tier and evicted only
        after all ordinary blocks have been evicted.  No-op if
        LMCACHE_DISABLE_RESIDENT_INDEXER=1.

        Args:
            token_id: Global token position to protect.
        """
        if not _RESIDENT_ENABLED:
            return
        slot = self._id_to_slot.get(token_id)
        if slot is None or slot in self._resident_slots:
            return
        self._lru_ordinary.pop(slot, None)
        self._lru_resident[slot] = None
        self._resident_slots.add(slot)

    def reset(self) -> None:
        """Clear all pool metadata before loading a new sequence."""
        self.pool_ids.fill_(-1)
        self._id_to_slot.clear()
        self._free = list(range(self._pool_size))
        self._lru_ordinary.clear()
        self._lru_resident.clear()
        self._resident_slots.clear()

    def get_slot(self, token_id: int) -> int:
        """Return pool slot for *token_id*; raise KeyError if not present."""
        return self._id_to_slot[token_id]

    def evict_to_ssd(self, store: IndexerBlockStore) -> None:
        """Write every in-pool token to SSD (called after prefill)."""
        flat_pool = self.pool_tensor.view(-1, self._token_bytes)
        for token_id, slot in self._id_to_slot.items():
            raw = flat_pool[slot].cpu().numpy().tobytes()
            store.write_token(token_id, raw)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _touch(self, slot: int) -> None:
        if slot in self._resident_slots:
            self._lru_resident.move_to_end(slot)
        elif slot in self._lru_ordinary:
            self._lru_ordinary.move_to_end(slot)

    def _evict_one(self) -> int:
        if self._lru_ordinary:
            slot, _ = self._lru_ordinary.popitem(last=False)
        elif self._lru_resident:
            slot, _ = self._lru_resident.popitem(last=False)
            self._resident_slots.discard(slot)
        else:
            raise RuntimeError("IndexerHBMPool: both LRU queues are empty")
        old_id = int(self.pool_ids[slot].item())
        if old_id >= 0:
            del self._id_to_slot[old_id]
        return slot


# ---------------------------------------------------------------------------
# Top-level manager
# ---------------------------------------------------------------------------

class IndexerSSDManager:
    """Manages SSD-backed HBM pools for all CSA Indexer layers in DeepSeek V4.

    One instance is shared across all CSA layers.  Each CSA layer has its own
    :class:`IndexerHBMPool` and :class:`IndexerBlockStore`.

    The manager is invoked from two call sites in the vLLM forward pass:

    1. **Before MoE FFN** (``DeepseekV2DecoderLayer.forward``):
       :meth:`fire_async_for_layer` kicks off async NVMe reads for the
       predicted delta blocks of the next CSA layer.

    2. **Inside SparseAttnIndexer scoring** (``sparse_attn_indexer.py``):
       :meth:`prepare_pool` drains pending async reads, then returns the pool
       tensor + a block_table for the current sequence.  After the topk kernel
       runs, :meth:`record_topk` saves the result for the next step.
    """

    def __init__(
        self,
        csa_layer_ids: List[int],
        store_dir: str,
        pool_size: int,
        token_bytes: int,
        max_seq_len: int,
        io_workers: int,
        device: torch.device,
    ) -> None:
        """
        Args:
            csa_layer_ids: Sorted list of CSA layer indices in the model.
            store_dir: Directory for SSD backing files.
            pool_size: HBM pool capacity in tokens per CSA layer.
            token_bytes: Bytes per token (head_dim + scale overhead).
            max_seq_len: Maximum context length for SSD file sizing.
            io_workers: Number of async I/O threads.
            device: CUDA device for HBM pools.
        """
        self._csa_layer_ids = csa_layer_ids
        self._store_dir = store_dir
        self._pool_size = pool_size
        self._token_bytes = token_bytes
        self._device = device

        # Per-layer HBM pool
        self._pools: Dict[int, IndexerHBMPool] = {
            lid: IndexerHBMPool(pool_size, token_bytes, device)
            for lid in csa_layer_ids
        }
        # Per-layer SSD store
        self._stores: Dict[int, IndexerBlockStore] = {
            lid: IndexerBlockStore(store_dir, lid, token_bytes, max_seq_len)
            for lid in csa_layer_ids
        }

        # Async I/O
        self._executor = ThreadPoolExecutor(max_workers=io_workers)
        self._lock = threading.Lock()
        # pending async read results: layer_id → list of (token_id, Future[bytes])
        self._pending: Dict[int, List[Tuple[int, "Future[bytes]"]]] = {
            lid: [] for lid in csa_layer_ids
        }

        # Per-layer speculative topk from previous step: token IDs
        self._prev_topk: Dict[int, Optional[List[int]]] = {
            lid: None for lid in csa_layer_ids
        }
        self._decoder_layers: Dict[int, Any] = {}

        # Future tracking for post-prefill async SSD eviction.
        # prepare_pool blocks on this before scoring if it's not yet done.
        self._ready_futures: Dict[int, Optional[Future[None]]] = {
            lid: None for lid in csa_layer_ids
        }

        # Next sequential token ID for new decode-step tokens, per layer.
        # Set to seq_len by evict_after_prefill; incremented on each decode step.
        # Stays 0 until eviction runs (acts as "SSD uninitialized" guard).
        self._decode_cursor: Dict[int, int] = {lid: 0 for lid in csa_layer_ids}

        # CSA layer index → position in csa_layer_ids list (for "next CSA layer" lookup)
        self._csa_pos: Dict[int, int] = {lid: i for i, lid in enumerate(csa_layer_ids)}
        self._debug_evict_logged: set[int] = set()
        self._debug_prepare_logged: set[int] = set()
        self._debug_insert_logged: set[int] = set()
        self._debug_topk_logged: set[int] = set()
        self._debug_fire_no_prev_logged: set[int] = set()
        self._debug_fire_active_logged: set[int] = set()
        self._debug_residual_proxy_logged: set[int] = set()

    def register_decoder_layer(self, layer_id: int, decoder_layer: Any) -> None:
        """Register a decoder layer for optional residual proxy prefetch."""
        self._decoder_layers[layer_id] = decoder_layer

    # ------------------------------------------------------------------
    # Called from DeepseekV2DecoderLayer.forward, before self.mlp()
    # ------------------------------------------------------------------

    def fire_async_for_layer(
        self,
        layer_id: int,
        residual_proxy: Optional[torch.Tensor] = None,
        positions: Optional[torch.Tensor] = None,
        llama_4_scaling: Optional[torch.Tensor] = None,
    ) -> None:
        """Fire async NVMe reads for the predicted delta of *layer_id*.

        Uses the previous step's true topk for *layer_id* to predict which
        tokens will be needed.  Tokens already in the HBM pool are skipped.
        Should be called before the MoE FFN of the block immediately preceding
        *layer_id* to overlap I/O with compute.

        Args:
            layer_id: CSA layer for which to prefetch.
        """
        prev = None
        if _RESIDUAL_PROXY_ENABLED and residual_proxy is not None and positions is not None:
            prev = self._residual_proxy_topk(
                layer_id,
                residual_proxy,
                positions,
                llama_4_scaling,
            )
        if prev is None:
            prev = self._prev_topk.get(layer_id)
        if prev is None:
            if layer_id not in self._debug_fire_no_prev_logged:
                self._debug_fire_no_prev_logged.add(layer_id)
                logger.info(
                    "IndexerSSDManager: fire_async_for_layer layer %d has no "
                    "previous topk yet",
                    layer_id,
                )
            return
        pool = self._pools[layer_id]
        store = self._stores[layer_id]
        missing = [tid for tid in prev if not pool.contains(tid)]
        if not missing:
            if layer_id not in self._debug_fire_active_logged:
                self._debug_fire_active_logged.add(layer_id)
                logger.info(
                    "IndexerSSDManager: fire_async_for_layer layer %d active, "
                    "prev_topk=%d, all already resident",
                    layer_id,
                    len(prev),
                )
            return
        if layer_id not in self._debug_fire_active_logged:
            self._debug_fire_active_logged.add(layer_id)
            logger.info(
                "IndexerSSDManager: fire_async_for_layer layer %d active, "
                "prev_topk=%d, missing=%d",
                layer_id,
                len(prev),
                len(missing),
            )
        futures = [
            (tid, self._executor.submit(store.read_token, tid))
            for tid in missing
        ]
        with self._lock:
            self._pending[layer_id].extend(futures)

    def _residual_proxy_topk(
        self,
        layer_id: int,
        residual_proxy: torch.Tensor,
        positions: torch.Tensor,
        llama_4_scaling: Optional[torch.Tensor],
    ) -> Optional[List[int]]:
        """Run the next CSA layer's indexer on attention+residual proxy state."""
        decoder_layer = self._decoder_layers.get(layer_id)
        if decoder_layer is None:
            return None
        if residual_proxy.shape[0] != 1:
            return None
        self_attn = getattr(decoder_layer, "self_attn", None)
        indexer = getattr(self_attn, "indexer", None)
        indexer_rope_emb = getattr(self_attn, "indexer_rope_emb", None)
        input_layernorm = getattr(decoder_layer, "input_layernorm", None)
        if indexer is None or indexer_rope_emb is None or input_layernorm is None:
            return None

        with torch.no_grad():
            proxy_hidden = input_layernorm(residual_proxy)
            q_c = self._proxy_q_c(self_attn, proxy_hidden)
            indexer_op = getattr(indexer, "indexer_op", None)
            old_ssd_manager = getattr(indexer_op, "ssd_manager", None)
            old_skip_insert = getattr(indexer_op, "skip_k_cache_insert", None)
            if indexer_op is not None:
                indexer_op.ssd_manager = None
                indexer_op.skip_k_cache_insert = True
            try:
                indexer(proxy_hidden, q_c, positions, indexer_rope_emb)
            finally:
                if indexer_op is not None:
                    indexer_op.ssd_manager = old_ssd_manager
                    if old_skip_insert is not None:
                        indexer_op.skip_k_cache_insert = old_skip_insert
            topk_buf = getattr(indexer_op, "topk_indices_buffer", None)
            if topk_buf is None:
                topk_buf = getattr(indexer, "topk_indices_buffer", None)
            if topk_buf is None:
                return None
            valid = topk_buf.reshape(-1)
            valid = valid[valid >= 0]
            token_ids = [int(x) for x in valid[:1024].cpu().tolist()]
        if layer_id not in self._debug_residual_proxy_logged:
            self._debug_residual_proxy_logged.add(layer_id)
            logger.info(
                "IndexerSSDManager: residual_proxy layer %d spec_tokens=%d",
                layer_id,
                len(token_ids),
            )
        return token_ids

    @staticmethod
    def _proxy_q_c(self_attn: Any, proxy_hidden: torch.Tensor) -> Optional[torch.Tensor]:
        """Compute the q_c input expected by the DeepSeek CSA indexer."""
        mla_attn = getattr(self_attn, "mla_attn", None)
        if mla_attn is None:
            return None
        fused_qkv_a_proj = getattr(mla_attn, "fused_qkv_a_proj", None)
        q_lora_rank = getattr(mla_attn, "q_lora_rank", None)
        q_a_layernorm = getattr(mla_attn, "q_a_layernorm", None)
        if fused_qkv_a_proj is not None and q_lora_rank is not None:
            qkv_lora = fused_qkv_a_proj(proxy_hidden)[0]
            q_c = qkv_lora[:, : int(q_lora_rank)]
            return q_a_layernorm(q_c) if q_a_layernorm is not None else q_c
        return None

    # ------------------------------------------------------------------
    # Called from SparseAttnIndexer, before scoring
    # ------------------------------------------------------------------

    def prepare_pool(
        self, layer_id: int
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Drain pending async reads into the HBM pool for *layer_id*.

        Blocks if a post-prefill SSD eviction future is still running so the
        pool is populated before scoring begins.

        Returns:
            pool_tensor: [pool_size, 1, 1, token_bytes] uint8 on CUDA.
            block_table: [1, pool_size] int32 on CUDA (sequential 0..pool_size-1).
        """
        with self._lock:
            ready_fut = self._ready_futures.get(layer_id)
        if ready_fut is not None:
            if not ready_fut.done():
                logger.info(
                    "IndexerSSDManager: waiting for post-prefill SSD init layer %d",
                    layer_id,
                )
            ready_fut.result(timeout=120.0)
            with self._lock:
                if self._ready_futures.get(layer_id) is ready_fut:
                    self._ready_futures[layer_id] = None
        self._drain(layer_id)
        pool = self._pools[layer_id]
        if layer_id not in self._debug_prepare_logged:
            self._debug_prepare_logged.add(layer_id)
            valid_slots = int((pool.pool_ids >= 0).sum().item())
            logger.info(
                "IndexerSSDManager: prepare_pool layer %d valid_slots=%d",
                layer_id,
                valid_slots,
            )
        return pool.pool_tensor, pool.block_table

    def pool_ids_for_layer(self, layer_id: int) -> torch.Tensor:
        """Return pool_ids tensor [pool_size] int64 for *layer_id*.

        Used to translate pool-slot topk indices back to global token IDs.
        """
        return self._pools[layer_id].pool_ids

    # ------------------------------------------------------------------
    # Called from SparseAttnIndexer, after scoring
    # ------------------------------------------------------------------

    def translate_pool_slots(
        self, layer_id: int, topk_pool_slots: torch.Tensor
    ) -> torch.Tensor:
        """Translate pool-slot top-k indices to global token IDs.

        Args:
            layer_id: CSA layer that just ran scoring.
            topk_pool_slots: 1-D int32 tensor of pool slot indices (on CUDA).

        Returns:
            Tensor with the same shape as ``topk_pool_slots`` containing global
            token IDs. Empty pool slots are translated to ``-1``.
        """
        pool = self._pools[layer_id]
        flat_slots = topk_pool_slots.to(device=pool.pool_ids.device, dtype=torch.long)
        valid = (flat_slots >= 0) & (flat_slots < pool.pool_ids.numel())
        translated = torch.full_like(flat_slots, -1, dtype=pool.pool_ids.dtype)
        if valid.any():
            translated[valid] = pool.pool_ids[flat_slots[valid]]
        return translated.reshape(topk_pool_slots.shape).to(device=topk_pool_slots.device)

    def record_topk(self, layer_id: int, topk_pool_slots: torch.Tensor) -> None:
        """Record top-k pool slots for use as next step's prediction.

        Args:
            layer_id: CSA layer that just ran scoring.
            topk_pool_slots: 1-D int32 tensor of pool slot indices.
        """
        global_topk = self.translate_pool_slots(layer_id, topk_pool_slots)
        self.record_global_topk(layer_id, global_topk)

    def record_global_topk(self, layer_id: int, token_ids_tensor: torch.Tensor) -> None:
        """Record global token IDs for use as next step's prediction.

        Args:
            layer_id: CSA layer that just ran scoring.
            token_ids_tensor: Tensor containing global token IDs.
        """
        token_ids = []
        for tid in token_ids_tensor.reshape(-1).cpu().tolist():
            tid_int = int(tid)
            if tid_int >= 0:
                token_ids.append(tid_int)
        self._prev_topk[layer_id] = token_ids
        if layer_id not in self._debug_topk_logged:
            self._debug_topk_logged.add(layer_id)
            logger.info(
                "IndexerSSDManager: record_global_topk layer %d count=%d",
                layer_id,
                len(token_ids),
            )

    def insert_decode_token(self, layer_id: int, data: bytes) -> Optional[int]:
        """Insert the current decode token into the HBM pool and SSD store.

        The decode cursor is initialized by :meth:`evict_after_prefill`. If the
        layer has not been initialized yet, this method is a no-op.

        Args:
            layer_id: CSA layer index.
            data: Raw uint8 bytes in the same layout as the IndexerCache.

        Returns:
            Global token ID assigned to the inserted decode token, or ``None``
            when SSD state has not been initialized.
        """
        if len(data) != self._token_bytes:
            raise ValueError(
                f"Expected {self._token_bytes} bytes, got {len(data)}"
            )
        with self._lock:
            token_id = self._decode_cursor.get(layer_id, 0)
            if token_id <= 0:
                return None
            self._decode_cursor[layer_id] = token_id + 1
        self._pools[layer_id].insert(token_id, data)
        self._stores[layer_id].write_token(token_id, data)
        if layer_id not in self._debug_insert_logged:
            self._debug_insert_logged.add(layer_id)
            logger.info(
                "IndexerSSDManager: insert_decode_token layer %d token_id=%d",
                layer_id,
                token_id,
            )
        return token_id

    # ------------------------------------------------------------------
    # Called after prefill to evict IndexerCache to SSD
    # ------------------------------------------------------------------

    def evict_after_prefill(
        self,
        layer_id: int,
        kv_cache_tensor: torch.Tensor,
        seq_len: int,
        seed_token_ids: Optional[List[int]] = None,
        slot_mapping: Optional[torch.Tensor] = None,
        block_table: Optional[torch.Tensor] = None,
    ) -> None:
        """Populate pool + SSD from vLLM's IndexerCache tensor after prefill.

        Reads all *seq_len* token K-vectors from *kv_cache_tensor* (vLLM's
        paged IndexerCache), writes them to SSD, and loads
        *pool_size* of them into the HBM pool (using the seed tokens if
        provided, otherwise the first pool_size tokens).

        Args:
            layer_id: CSA layer index.
            kv_cache_tensor: vLLM's IndexerCache tensor
                ``[num_blocks, block_size, 1, token_bytes]`` uint8 on CPU
                (caller must transfer to CPU before calling).
            seq_len: Number of valid tokens (context length after prefill).
            seed_token_ids: Sequence positions (0..seq_len-1) to prioritize in
                HBM pool (prefill topk); marked as resident (lower eviction priority).
            slot_mapping: Optional tensor [seq_len] mapping sequence position i
                to its physical vLLM slot in *kv_cache_tensor*.  When provided,
                token i is read from kv_cache_tensor[slot//block_size, slot%block_size].
                When None, sequential layout (token i = block i//bs, offset i%bs) is assumed.
            block_table: Optional tensor mapping logical block IDs to physical vLLM
                block IDs.  When provided, it is expanded into a slot mapping for
                the full compressed IndexerCache sequence.
        """
        pool = self._pools[layer_id]
        store = self._stores[layer_id]
        block_size = kv_cache_tensor.shape[1]
        pool.reset()

        if block_table is not None:
            slot_mapping = self._slot_mapping_from_block_table(
                block_table, seq_len, block_size
            )

        def _token_bytes_for(tid: int) -> bytes:
            if slot_mapping is not None:
                slot = int(slot_mapping[tid].item())
                if slot < 0:
                    raise ValueError(
                        f"Invalid negative slot {slot} for token {tid} "
                        f"at layer {layer_id}"
                    )
                blk = slot // block_size
                off = slot % block_size
            else:
                blk = tid // block_size
                off = tid % block_size
            token = kv_cache_tensor[blk, off]
            if token.ndim > 1:
                token = token.reshape(-1)
            data = bytes(token.contiguous().numpy().tobytes())
            if len(data) != self._token_bytes:
                raise ValueError(
                    f"Expected {self._token_bytes} bytes for layer {layer_id} "
                    f"token {tid}, got {len(data)} from kv_cache shape "
                    f"{tuple(kv_cache_tensor.shape)}"
                )
            return data

        # Write all tokens to SSD
        for tid in range(seq_len):
            store.write_token(tid, _token_bytes_for(tid))

        # Load seed tokens into HBM pool first
        load_ids: List[int] = []
        if seed_token_ids:
            load_ids = seed_token_ids[: self._pool_size]
        if len(load_ids) < self._pool_size:
            seed_set = set(load_ids)
            extra = [tid for tid in range(seq_len) if tid not in seed_set]
            load_ids += extra[: self._pool_size - len(load_ids)]

        for tid in load_ids:
            pool.insert(tid, _token_bytes_for(tid))

        # Protect seed tokens so they are evicted last
        if seed_token_ids:
            for tid in seed_token_ids[: self._pool_size]:
                pool.protect(tid)

        # Initialize prev_topk and decode cursor
        if seed_token_ids:
            self._prev_topk[layer_id] = list(seed_token_ids[:1024])
        with self._lock:
            self._decode_cursor[layer_id] = seq_len
        if layer_id not in self._debug_evict_logged:
            self._debug_evict_logged.add(layer_id)
            logger.info(
                "IndexerSSDManager: evict_after_prefill complete layer %d "
                "seq_len=%d seed_tokens=%d",
                layer_id,
                seq_len,
                len(seed_token_ids or []),
            )

    def submit_evict_after_prefill(
        self,
        layer_id: int,
        kv_cache_cpu: torch.Tensor,
        seq_len: int,
        seed_token_ids: Optional[List[int]] = None,
        slot_mapping_cpu: Optional[torch.Tensor] = None,
        block_table_cpu: Optional[torch.Tensor] = None,
    ) -> None:
        """Submit :meth:`evict_after_prefill` to the I/O thread pool.

        The tensors must already be on CPU (caller's responsibility to call
        ``.cpu()`` on CUDA tensors before invoking this method).
        :meth:`prepare_pool` will block on the resulting future so the pool
        is populated before the first decode step scores against it.

        Args:
            layer_id: CSA layer index.
            kv_cache_cpu: IndexerCache tensor already on CPU.
            seq_len: Number of valid prefill tokens.
            seed_token_ids: Prefill topk sequence positions.
            slot_mapping_cpu: Slot mapping tensor already on CPU.
            block_table_cpu: Block table tensor already on CPU.
        """
        with self._lock:
            previous_future = self._ready_futures.get(layer_id)

        def _run_after_previous() -> None:
            if previous_future is not None:
                previous_future.result(timeout=120.0)
            self.evict_after_prefill(
                layer_id,
                kv_cache_cpu,
                seq_len,
                seed_token_ids,
                slot_mapping_cpu,
                block_table_cpu,
            )

        future = self._executor.submit(_run_after_previous)
        with self._lock:
            self._ready_futures[layer_id] = future
        logger.info(
            "IndexerSSDManager: submit_evict_after_prefill layer %d seq_len=%d "
            "seed_tokens=%d",
            layer_id,
            seq_len,
            len(seed_token_ids or []),
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _slot_mapping_from_block_table(
        block_table: torch.Tensor, seq_len: int, block_size: int
    ) -> torch.Tensor:
        """Expand a vLLM block table row into per-token physical slot IDs."""
        if block_table.ndim == 2:
            block_row = block_table[0]
        elif block_table.ndim == 1:
            block_row = block_table
        else:
            raise ValueError(
                f"Expected 1D/2D block_table, got shape {tuple(block_table.shape)}"
            )
        num_blocks = (seq_len + block_size - 1) // block_size
        block_row = block_row[:num_blocks].to(dtype=torch.long, device="cpu")
        offsets = torch.arange(block_size, dtype=torch.long).repeat(num_blocks)
        slots = block_row.repeat_interleave(block_size) * block_size + offsets
        return slots[:seq_len]

    def _drain(self, layer_id: int) -> None:
        """Wait for all pending async reads for *layer_id* and insert into pool."""
        with self._lock:
            pending = self._pending.get(layer_id, [])
            self._pending[layer_id] = []
        pool = self._pools[layer_id]
        store = self._stores[layer_id]
        for tid, fut in pending:
            try:
                data = fut.result()
                if data:
                    pool.insert(tid, data)
            except Exception as exc:
                logger.warning(
                    "IndexerSSDManager: async read failed for token %d layer %d: %r",
                    tid, layer_id, exc,
                )
                # Fallback: synchronous read
                try:
                    data = store.read_token(tid)
                    if data:
                        pool.insert(tid, data)
                except Exception as exc2:
                    logger.error(
                        "IndexerSSDManager: fallback sync read also failed: %s", exc2
                    )

    def reset(self) -> None:
        """Reset all per-step state (prev_topk, pending reads, cursors).

        Call between benchmark runs or when starting a new sequence.
        """
        with self._lock:
            for lid in self._csa_layer_ids:
                self._prev_topk[lid] = None
                self._pending[lid] = []
                self._ready_futures[lid] = None
                self._decode_cursor[lid] = 0

    def close(self) -> None:
        """Shut down I/O thread pool and close SSD files."""
        self._executor.shutdown(wait=True)
        for store in self._stores.values():
            store.close()

    # ------------------------------------------------------------------
    # Factory
    # ------------------------------------------------------------------

    @classmethod
    def from_vllm_model(
        cls,
        model: torch.nn.Module,
        store_dir: str,
        pool_size: int = 2048,
        io_workers: int = 8,
        max_seq_len: int = 131072,
    ) -> "IndexerSSDManager":
        """Construct an IndexerSSDManager by inspecting a vLLM DeepSeek model.

        Scans the model's layers for ``DeepseekV32IndexerCache`` instances to
        discover CSA layer IDs and pool configuration.

        Args:
            model: vLLM ``DeepseekV2ForCausalLM`` or similar.
            store_dir: Directory for SSD backing files.
            pool_size: HBM pool capacity in tokens per CSA layer.
            io_workers: Async I/O thread pool size.
            max_seq_len: Maximum context length.

        Returns:
            Configured :class:`IndexerSSDManager` instance.

        Raises:
            ValueError: If no CSA layers are found in the model.
        """
        from vllm.model_executor.models.deepseek_v2 import DeepseekV32IndexerCache

        csa_layer_ids: List[int] = []
        token_bytes: Optional[int] = None
        device: Optional[torch.device] = None

        for name, module in model.named_modules():
            if isinstance(module, DeepseekV32IndexerCache):
                # Extract layer index from prefix like "model.layers.3.self_attn.indexer.k_cache"
                parts = name.split(".")
                for i, p in enumerate(parts):
                    if p == "layers" and i + 1 < len(parts):
                        try:
                            lid = int(parts[i + 1])
                            csa_layer_ids.append(lid)
                        except ValueError:
                            pass
                        break
                if token_bytes is None and module.kv_cache.numel() > 0:
                    token_bytes = module.head_dim
                if device is None and module.kv_cache.numel() > 0:
                    device = module.kv_cache.device

        if not csa_layer_ids:
            raise ValueError(
                "IndexerSSDManager.from_vllm_model: no DeepseekV32IndexerCache "
                "layers found in model"
            )

        csa_layer_ids = sorted(set(csa_layer_ids))
        if token_bytes is None:
            # Infer from model config
            token_bytes = 144  # FP8 head_dim=128 + 16-byte scale overhead (heuristic)
        if device is None:
            device = torch.device("cuda")

        return cls(
            csa_layer_ids=csa_layer_ids,
            store_dir=store_dir,
            pool_size=pool_size,
            token_bytes=token_bytes,
            max_seq_len=max_seq_len,
            io_workers=io_workers,
            device=device,
        )
